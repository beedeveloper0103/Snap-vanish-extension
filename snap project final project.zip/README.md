# Snap Vanish

## For a clean, full-frame vanish
1. Open your meeting and make sure Snap Vanish shows Ready.
2. Step completely out of the webcam view.
3. Open the extension popup and click **Learn empty room**.
4. Wait at least 5 seconds while the camera sees the empty room.
5. Return to your seat without changing the camera angle or lighting.
6. Click **Snap now** to test the dissolve. When fully vanished, the output uses the learned empty-room frame across the whole image.

If you learn the room while you are still in frame, the extension cannot know what was behind your body and may have to estimate those pixels. A real empty-room capture gives the clearest result.

This extension modifies the video stream locally in the browser. Compatibility with individual meeting websites and live calls can vary.
