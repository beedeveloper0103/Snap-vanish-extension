Snap Vanish diagnostic build

The MediaPipe line "OpenGL error checking is disabled" is a warning emitted by the bundled MediaPipe/WebGL runtime. It does not, by itself, indicate a failed WebGL context; the adjacent "Successfully created a WebGL context" and "GL version" lines indicate context creation succeeded.

This build forwards actionable window errors, unhandled promise rejections, and frame-processing exceptions (including stack traces) to the extension's existing error message channel. To debug a real failure:
1. Reload the unpacked extension at chrome://extensions.
2. Reload the meeting tab.
3. Open DevTools > Console and enable the Errors filter.
4. Look for red errors or messages beginning [Snap Vanish], not only the MediaPipe W0000 warning.
5. Also check DevTools > Network for failed requests to vendor/hands or vendor/selfie_segmentation.

The warning originates in the bundled MediaPipe runtime and cannot safely be fixed by changing the extension's OpenGL settings. This build improves error reporting; it does not suppress the runtime warning or claim to fix an unrelated runtime failure.
