const DEFAULTS = { enabled: true, sensitivity: 5, duration: 2.5, direction: 'upright', needSound: true };
const $ = (id) => document.getElementById(id);
const save = () => chrome.storage.sync.set({
  enabled: $('enabled').checked, sensitivity: +$('sensitivity').value, duration: +$('duration').value,
  direction: $('direction').value, needSound: $('needSound').checked,
});
const labels = () => { $('sv').textContent = $('sensitivity').value; $('dv').textContent = $('duration').value + 's'; };

chrome.storage.sync.get(DEFAULTS, (v) => {
  $('enabled').checked = v.enabled; $('sensitivity').value = v.sensitivity; $('duration').value = v.duration;
  $('direction').value = v.direction; $('needSound').checked = v.needSound; labels();
});
['enabled', 'sensitivity', 'duration', 'direction', 'needSound'].forEach((id) => $(id).addEventListener('input', () => { labels(); save(); }));

const tabMsg = async (m) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return null;
  try { return await chrome.tabs.sendMessage(tab.id, m); } catch (_) { return null; }
};
$('snap').addEventListener('click', () => tabMsg({ type: 'snapNow' }));
$('relearn').addEventListener('click', () => tabMsg({ type: 'relearn' }));

chrome.commands.getAll((cmds) => { const c = cmds.find((x) => x.name === 'snap-now'); $('key').textContent = (c && c.shortcut) || 'not set'; });

async function refresh() {
  const s = await tabMsg({ type: 'getStatus' });
  let t;
  if (!s) t = 'No camera in use on this tab. Open Meet, Teams or Zoom on the web and join with your camera on.';
  else if (s.engine === 'error') t = 'The local AI engine could not start. Reload the call tab.';
  else if (s.engine === 'loading') t = 'Loading the local AI models… your normal camera is used meanwhile.';
  else t = (s.state === 'gone' || s.state === 'vanishing' ? 'You are gone. ' : 'Ready. ') + 'Room learned: ' + s.coverage + '%' + (s.audio ? '' : ' · mic not detected, gesture-only');
  $('status').textContent = t;
}
refresh(); setInterval(refresh, 1500);
