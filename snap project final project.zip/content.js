// Isolated-world bridge: settings + popup/shortcut messages <-> page-world inject.js
(() => {
  const TAG = '__sv';
  const DEFAULTS = { enabled: true, sensitivity: 5, duration: 2.5, direction: 'upright', needSound: true };
  let cfg = { ...DEFAULTS };
  let status = null;

  // Tell the page-world script where the (hidden) local AI engine page lives.
  document.documentElement.dataset.svEngine = chrome.runtime.getURL('engine.html');

  const toMain = (m) => window.postMessage({ [TAG]: 1, to: 'main', ...m }, '*');
  const load = () => chrome.storage.sync.get(DEFAULTS, (v) => { cfg = { ...DEFAULTS, ...v }; toMain({ type: 'cfg', cfg }); });
  load();
  chrome.storage.onChanged.addListener(load);

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (e.source !== window || !d || !d[TAG] || d.to !== 'content') return;
    if (d.type === 'hello') toMain({ type: 'cfg', cfg });
    else if (d.type === 'status') status = d.status;
    else if (d.type === 'toast') toast(d.text);
  });

  chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m.type === 'getStatus') { if (status && status.hasPipeline) reply(status); return; }
    toMain(m); // snapNow, relearn
  });

  let toastEl;
  function toast(text) {
    if (window !== window.top) return;
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483647;' +
        'background:#1d1b1a;color:#ece6dc;font:500 14px/1.4 system-ui,sans-serif;padding:10px 16px;border-radius:10px;' +
        'box-shadow:0 6px 24px rgba(0,0,0,.4);max-width:420px;text-align:center;transition:opacity .4s;opacity:0;pointer-events:none';
      (document.body || document.documentElement).appendChild(toastEl);
    }
    toastEl.textContent = text;
    toastEl.style.opacity = '1';
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => (toastEl.style.opacity = '0'), 8000);
  }
})();
