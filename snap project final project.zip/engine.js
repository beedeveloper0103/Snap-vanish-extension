// Snap Vanish local engine: hand tracking, person cutout, room learning, dust effect.
// Runs in an extension page (hidden iframe). Nothing here touches the network.
(() => {
  'use strict';
  const parentWin = window.parent;
  const send = (m, tr) => parentWin.postMessage(m, '*', tr || []);
  // Forward actionable browser/runtime failures to the extension UI with stack traces.
  window.addEventListener('error', (e) => {
    send({ t: 'error', msg: 'window error: ' + (e.message || 'unknown'), stack: e.error && e.error.stack || '', file: e.filename || '', line: e.lineno || 0, column: e.colno || 0 });
  });
  window.addEventListener('unhandledrejection', (e) => {
    const r = e.reason; send({ t: 'error', msg: 'unhandled promise rejection: ' + String(r && r.message || r || 'unknown'), stack: r && r.stack || '' });
  });
  const clamp = (v, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
  const smooth = (a, b, v) => { const t = clamp((v - a) / (b - a)); return t * t * (3 - 2 * t); };

  let cfg = { enabled: true, sensitivity: 5, duration: 2.5, direction: 'upright' };
  const DIRS = { upright: [0.82, -0.57], right: [1, -0.08], left: [-1, -0.08], up: [0.05, -1], outward: null };
  const SPREAD = 0.55; // how much of the timeline is spent "releasing" particles

  let W = 0, H = 0, N = 0;
  let cv, cx, sx, outCv, outCx, outImg, frameData;
  let raw, tmp, mk, kmap, kdirty = true, useAlpha = false;
  let plateF, plateOut, known, fillRGB;
  let state = 'present', T = 0, lastT = 0, parts = null, pendingGo = null;
  let frameNo = 0, learnPasses = 0, busy = false, handRes = null, segRes = null;
  let forceLearnFrames = 0;
  let hands, seg;

  /* ---------- allocation ---------- */
  function ensureSize(w, h) {
    if (w === W && h === H) return;
    W = w; H = h; N = W * H;
    cv = Object.assign(document.createElement('canvas'), { width: W, height: H });
    cx = cv.getContext('2d', { willReadFrequently: true });
    const s = Object.assign(document.createElement('canvas'), { width: W, height: H });
    sx = s.getContext('2d', { willReadFrequently: true });
    outCv = Object.assign(document.createElement('canvas'), { width: W, height: H });
    outCx = outCv.getContext('2d');
    outImg = outCx.createImageData(W, H);
    raw = new Float32Array(N); tmp = new Float32Array(N); mk = new Float32Array(N); kmap = new Float32Array(N);
    plateF = new Float32Array(N * 3); plateOut = new Uint8ClampedArray(N * 3); fillRGB = new Uint8ClampedArray(N * 3);
    known = new Uint8Array(N); kdirty = true; learnPasses = 0;
  }

  /* ---------- mask ---------- */
  function box(src, dst, r) {
    const k = 1 / (2 * r + 1);
    for (let y = 0; y < H; y++) {
      const o = y * W; let s = 0;
      for (let x = -r; x <= r; x++) s += src[o + Math.min(W - 1, Math.max(0, x))];
      for (let x = 0; x < W; x++) { tmp[o + x] = s * k; s += src[o + Math.min(W - 1, x + r + 1)] - src[o + Math.max(0, x - r)]; }
    }
    for (let x = 0; x < W; x++) {
      let s = 0;
      for (let y = -r; y <= r; y++) s += tmp[Math.min(H - 1, Math.max(0, y)) * W + x];
      for (let y = 0; y < H; y++) { dst[y * W + x] = s * k; s += tmp[Math.min(H - 1, y + r + 1) * W + x] - tmp[Math.max(0, y - r) * W + x]; }
    }
  }
  function updateMask() {
    const m = segRes && segRes.segmentationMask; if (!m) return;
    sx.clearRect(0, 0, W, H); sx.drawImage(m, 0, 0, W, H);
    const d = sx.getImageData(0, 0, W, H).data;
    if (!useAlpha) for (let i = 3; i < d.length; i += 388) if (d[i] < 250) { useAlpha = true; break; }
    const ch = useAlpha ? 3 : 0;
    for (let i = 0; i < N; i++) raw[i] = d[i * 4 + ch] / 255;
    box(raw, raw, 4); box(raw, raw, 4); // feather, then threshold low = slightly grown mask (hides halos)
    for (let i = 0; i < N; i++) mk[i] = smooth(0.035, 0.32, raw[i]);
  }

  /* ---------- room plate (what's behind you) ---------- */
  function learn() {
    const f = frameData; let unknown = 0;
    // During explicit empty-room calibration, trust the whole frame. The user must
    // leave the camera view first; this avoids segmentation-mask ghosts in the plate.
    const forceWholeFrame = forceLearnFrames > 0;
    if (forceLearnFrames > 0) forceLearnFrames--;
    for (let i = 0, j = 0, p = 0; i < N; i++, j += 3, p += 4) {
      if (forceWholeFrame || mk[i] < 0.01) {
        if (known[i]) { plateF[j] += (f[p] - plateF[j]) * 0.04; plateF[j + 1] += (f[p + 1] - plateF[j + 1]) * 0.04; plateF[j + 2] += (f[p + 2] - plateF[j + 2]) * 0.04; }
        else { known[i] = 1; plateF[j] = f[p]; plateF[j + 1] = f[p + 1]; plateF[j + 2] = f[p + 2]; }
      }
      if (known[i]) { plateOut[j] = plateF[j]; plateOut[j + 1] = plateF[j + 1]; plateOut[j + 2] = plateF[j + 2]; }
      else { unknown++; plateOut[j] = fillRGB[j]; plateOut[j + 1] = fillRGB[j + 1]; plateOut[j + 2] = fillRGB[j + 2]; }
    }
    learnPasses++;
    if (unknown && (learnPasses < 4 || learnPasses % 20 === 0)) computeFill();
    cover = 1 - unknown / N;
  }
  let cover = 0;
  // Fills never-seen areas by spreading colours inward from what the camera has seen (low-res diffusion).
  function computeFill() {
    const cw = 64, ch = Math.max(8, Math.round((cw * H) / W));
    const acc = new Float32Array(cw * ch * 3), cnt = new Float32Array(cw * ch);
    for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) {
      const i = y * W + x; if (!known[i]) continue;
      const c = ((y * ch / H) | 0) * cw + ((x * cw / W) | 0);
      acc[c * 3] += plateF[i * 3]; acc[c * 3 + 1] += plateF[i * 3 + 1]; acc[c * 3 + 2] += plateF[i * 3 + 2]; cnt[c]++;
    }
    const v = new Float32Array(cw * ch * 3), isK = new Uint8Array(cw * ch); const mean = [0, 0, 0]; let n = 0;
    for (let c = 0; c < cw * ch; c++) if (cnt[c] >= 2) { isK[c] = 1; for (let k = 0; k < 3; k++) { v[c * 3 + k] = acc[c * 3 + k] / cnt[c]; mean[k] += v[c * 3 + k]; } n++; }
    if (!n) return;
    for (let k = 0; k < 3; k++) mean[k] /= n;
    for (let c = 0; c < cw * ch; c++) if (!isK[c]) for (let k = 0; k < 3; k++) v[c * 3 + k] = mean[k];
    for (let it = 0; it < 160; it++) for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) {
      const c = y * cw + x; if (isK[c]) continue;
      const nb = [x > 0 ? c - 1 : c, x < cw - 1 ? c + 1 : c, y > 0 ? c - cw : c, y < ch - 1 ? c + cw : c];
      for (let k = 0; k < 3; k++) v[c * 3 + k] = (v[nb[0] * 3 + k] + v[nb[1] * 3 + k] + v[nb[2] * 3 + k] + v[nb[3] * 3 + k]) / 4;
    }
    const sc = Object.assign(document.createElement('canvas'), { width: cw, height: ch }), scx = sc.getContext('2d');
    const im = scx.createImageData(cw, ch);
    for (let c = 0; c < cw * ch; c++) { im.data[c * 4] = v[c * 3]; im.data[c * 4 + 1] = v[c * 3 + 1]; im.data[c * 4 + 2] = v[c * 3 + 2]; im.data[c * 4 + 3] = 255; }
    scx.putImageData(im, 0, 0);
    sx.imageSmoothingEnabled = true; sx.drawImage(sc, 0, 0, W, H);
    const big = sx.getImageData(0, 0, W, H).data;
    for (let i = 0; i < N; i++) {
      fillRGB[i * 3] = big[i * 4]; fillRGB[i * 3 + 1] = big[i * 4 + 1]; fillRGB[i * 3 + 2] = big[i * 4 + 2];
      if (!known[i]) { plateOut[i * 3] = fillRGB[i * 3]; plateOut[i * 3 + 1] = fillRGB[i * 3 + 1]; plateOut[i * 3 + 2] = fillRGB[i * 3 + 2]; }
    }
  }

  /* ---------- dissolve order map + particles ---------- */
  function makeNoise(gw, gh) { const a = new Float32Array(gw * gh); for (let i = 0; i < a.length; i++) a[i] = Math.random(); return { a, gw, gh }; }
  function samp(nz, u, v) {
    const x = u * (nz.gw - 1), y = v * (nz.gh - 1), x0 = x | 0, y0 = y | 0, x1 = Math.min(nz.gw - 1, x0 + 1), y1 = Math.min(nz.gh - 1, y0 + 1);
    const fx = smooth(0, 1, x - x0), fy = smooth(0, 1, y - y0), g = (xx, yy) => nz.a[yy * nz.gw + xx];
    return (g(x0, y0) * (1 - fx) + g(x1, y0) * fx) * (1 - fy) + (g(x0, y1) * (1 - fx) + g(x1, y1) * fx) * fy;
  }
  function buildK() {
    const d = DIRS[cfg.direction], n1 = makeNoise(10, 6), n2 = makeNoise(32, 18);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const u = x / W, v = y / H, nz = 0.65 * samp(n1, u, v) + 0.35 * samp(n2, u, v);
      let base;
      if (d) { const p = ((u - 0.5) * d[0] + (v - 0.5) * d[1]) / (0.5 * (Math.abs(d[0]) + Math.abs(d[1]))); base = 1 - (p * 0.5 + 0.5); }
      else base = 1 - Math.min(1, Math.hypot(u - 0.5, v - 0.5) / 0.6);
      kmap[y * W + x] = clamp(base * 0.6 + nz * 0.4);
    }
    kdirty = false;
  }
  function buildParticles() {
    let cnt = 0; for (let i = 0; i < N; i++) if (mk[i] > 0.5) cnt++;
    const stride = Math.max(2, Math.ceil(Math.sqrt(cnt / 22000)));
    const cap = Math.ceil(W / stride) * Math.ceil(H / stride) + 8;
    const P = { n: 0, stride, x: new Float32Array(cap), y: new Float32Array(cap), r: new Uint8Array(cap), g: new Uint8Array(cap), b: new Uint8Array(cap),
      k: new Float32Array(cap), d: new Float32Array(cap), ux: new Float32Array(cap), uy: new Float32Array(cap), ph: new Float32Array(cap), am: new Float32Array(cap) };
    const dir = DIRS[cfg.direction];
    for (let y = 0; y < H; y += stride) for (let x = 0; x < W; x += stride) {
      const px = Math.min(W - 1, x + ((Math.random() * stride) | 0)), py = Math.min(H - 1, y + ((Math.random() * stride) | 0)), i = py * W + px;
      if (mk[i] <= 0.5) continue;
      const n = P.n++; P.x[n] = px; P.y[n] = py; P.r[n] = frameData[i * 4]; P.g[n] = frameData[i * 4 + 1]; P.b[n] = frameData[i * 4 + 2]; P.k[n] = kmap[i];
      let dx, dy; if (dir) { dx = dir[0]; dy = dir[1]; } else { dx = px - W / 2; dy = py - H / 2; const l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l; }
      const a = (Math.random() - 0.5) * 0.9, ca = Math.cos(a), sa = Math.sin(a);
      P.ux[n] = dx * ca - dy * sa; P.uy[n] = dx * sa + dy * ca;
      P.d[n] = W * (0.3 + 0.45 * Math.random()); P.ph[n] = Math.random() * 6.28; P.am[n] = W * (0.01 + 0.04 * Math.random());
    }
    parts = P;
  }
  function startAnim(gone) {
    if (kdirty) buildK();
    if (gone && state === 'present') { buildParticles(); state = 'vanishing'; T = 0; }
    else if (!gone && state === 'gone') { buildParticles(); state = 'returning'; T = 1; }
    else return;
    lastT = performance.now(); send({ t: 'state', state });
  }
  function advance() {
    const now = performance.now(), dt = (now - lastT) / 1000; lastT = now;
    if (state === 'vanishing') { T += dt / cfg.duration; if (T >= 1) { T = 1; state = 'gone'; parts = null; send({ t: 'state', state }); } }
    else if (state === 'returning') { T -= dt / (cfg.duration * 0.8); if (T <= 0) { T = 0; state = 'present'; parts = null; send({ t: 'state', state }); } }
  }

  /* ---------- compose ---------- */
  function compose() {
    const f = frameData, o = outImg.data;
    if (state === 'present') { o.set(f); return; }
    const gone = state === 'gone';
    // Once the dissolve finishes, never pass through the live camera frame.
    // Use the learned room plate across the entire output so no body/face pixels remain.
    if (gone) {
      for (let i = 0, p = 0, j = 0; i < N; i++, p += 4, j += 3) {
        o[p] = plateOut[j]; o[p + 1] = plateOut[j + 1]; o[p + 2] = plateOut[j + 2]; o[p + 3] = 255;
      }
      return;
    }
    for (let i = 0, p = 0, j = 0; i < N; i++, p += 4, j += 3) {
      const m = mk[i]; let g = m;
      if (!gone && m > 0) { const e = T - kmap[i] * SPREAD; g = m * (e < -0.025 ? 0 : e > 0.025 ? 1 : 0.5 + e * 20); }
      if (g > 0.003) { o[p] = f[p] + (plateOut[j] - f[p]) * g; o[p + 1] = f[p + 1] + (plateOut[j + 1] - f[p + 1]) * g; o[p + 2] = f[p + 2] + (plateOut[j + 2] - f[p + 2]) * g; }
      else { o[p] = f[p]; o[p + 1] = f[p + 1]; o[p + 2] = f[p + 2]; }
      o[p + 3] = 255;
    }
  }
  function drawParticles() {
    const P = parts; if (!P) return; const o = outImg.data;
    // Cinematic dust: warm gold sparks, varied sizes, restrained glow and motion streaks.
    for (let n = 0; n < P.n; n++) {
      const s = (T - P.k[n] * SPREAD) / (1 - SPREAD); if (s <= 0 || s >= 1) continue;
      const e = Math.pow(s, 1.45);
      const wobble = Math.sin(P.ph[n] + s * 10) * P.am[n] * s;
      const x = (P.x[n] + P.ux[n] * P.d[n] * e - P.uy[n] * wobble) | 0;
      const y = (P.y[n] + P.uy[n] * P.d[n] * e + P.ux[n] * wobble) | 0;
      const fade = s < 0.72 ? 1 : clamp((1 - s) / 0.28);
      if (x < 2 || y < 2 || x >= W - 2 || y >= H - 2) continue;
      const warm = clamp(0.25 + s * 0.75);
      const r = P.r[n] * (1 - warm * 0.55) + 255 * warm * 0.55;
      const g = P.g[n] * (1 - warm * 0.60) + 190 * warm * 0.60;
      const b = P.b[n] * (1 - warm * 0.70) + 92 * warm * 0.70;
      const size = s < 0.25 ? Math.max(2, P.stride) : (Math.random() < 0.12 ? 3 : 2);
      const glowA = 0.13 * fade;
      for (let gy = -2; gy <= 2; gy++) for (let gx = -2; gx <= 2; gx++) {
        const rr = gx * gx + gy * gy; if (rr > 5) continue;
        const q = ((y + gy) * W + x + gx) * 4;
        const a = glowA * (1 - rr / 6);
        o[q] = Math.min(255, o[q] + r * 0.8 * a);
        o[q + 1] = Math.min(255, o[q + 1] + g * 0.65 * a);
        o[q + 2] = Math.min(255, o[q + 2] + b * 0.35 * a);
      }
      if (s > 0.08) {
        const tx = (x - P.ux[n] * (3 + 8 * s)) | 0;
        const ty = (y - P.uy[n] * (3 + 8 * s)) | 0;
        if (tx >= 0 && ty >= 0 && tx < W && ty < H) {
          const q = (ty * W + tx) * 4, a = 0.35 * fade;
          o[q] = Math.min(255, o[q] + 255 * a);
          o[q + 1] = Math.min(255, o[q + 1] + 174 * a);
          o[q + 2] = Math.min(255, o[q + 2] + 70 * a);
        }
      }
      const a = 0.95 * fade;
      for (let yy = 0; yy < size; yy++) for (let xx = 0; xx < size; xx++) {
        const q = ((y + yy) * W + x + xx) * 4;
        o[q] = Math.min(255, o[q] * (1 - a) + r * a);
        o[q + 1] = Math.min(255, o[q + 1] * (1 - a) + g * a);
        o[q + 2] = Math.min(255, o[q + 2] * (1 - a) + b * a);
      }
    }
  }

  /* ---------- snap gesture (hand landmarks) ---------- */
  const gs = { phase: 0, n: 0, t: 0, relN: 0, rel: 0, lost: 0, cool: 0 };
  const resetG = () => { gs.phase = 0; gs.n = 0; gs.relN = 0; gs.lost = 0; };
  const dist = (a, b) => Math.hypot((a.x - b.x) * W, (a.y - b.y) * H);
  function detect(res, ts) {
    const hs = (res && res.multiHandLandmarks) || [];
    if (ts < gs.cool) return;
    if (!hs.length) { if (gs.phase && ++gs.lost > 4) resetG(); return; }
    gs.lost = 0;
    const S = cfg.sensitivity, pinchT = 0.15 + 0.02 * S, padT = 0.5 + 0.03 * S;
    for (const h of hs) {
      const size = dist(h[0], h[9]); if (size < 20) continue;
      const pinch = dist(h[4], h[12]) / size, pad = Math.min(dist(h[12], h[1]), dist(h[12], h[2]), dist(h[12], h[5])) / size;
      if (gs.phase === 0) { if (pinch < pinchT) { if (++gs.n >= 2) { gs.phase = 1; gs.t = ts; } } else gs.n = 0; }
      else if (gs.phase === 1) { if (pinch > pinchT * 1.35) { gs.phase = 2; gs.rel = ts; gs.relN = 0; } else if (ts - gs.t > 1500) resetG(); }
      if (gs.phase === 2) {
        if (pad < padT) { send({ t: 'candidate', ts }); gs.cool = ts + 1500; resetG(); }
        else if (++gs.relN > 5 || ts - gs.rel > 300) resetG();
      }
      break;
    }
  }

  /* ---------- frame loop ---------- */
  async function onFrame(bmp, ts) {
    try {
      ensureSize(bmp.width, bmp.height);
      cx.drawImage(bmp, 0, 0); bmp.close();
      frameData = cx.getImageData(0, 0, W, H).data; frameNo++;
      const anim = state === 'vanishing' || state === 'returning';
      const learnDue = !anim && frameNo % 4 === 0;
      if (anim || state === 'gone' || pendingGo || learnDue) { await seg.send({ image: cv }); updateMask(); }
      if (learnDue) learn();
      if (pendingGo) { startAnim(pendingGo.gone); pendingGo = null; }
      if (state === 'vanishing' || state === 'returning') advance();
      if (!anim) { await hands.send({ image: cv }); detect(handRes, ts); }
      compose(); drawParticles();
      outCx.putImageData(outImg, 0, 0);
      const b = await createImageBitmap(outCv);
      send({ t: 'out', bmp: b, ts }, [b]);
      if (frameNo % 30 === 0) send({ t: 'coverage', v: Math.round(cover * 100) });
    } catch (err) {
      send({ t: 'error', msg: String(err && err.message || err), stack: err && err.stack || '' }); send({ t: 'out', bmp: null });
    } finally { busy = false; }
  }

  window.addEventListener('message', (e) => {
    if (e.source !== parentWin) return;
    const d = e.data; if (!d) return;
    if (d.t === 'cfg') { if (d.cfg.direction !== cfg.direction) kdirty = true; cfg = { ...cfg, ...d.cfg }; }
    else if (d.t === 'frame') { if (busy || !hands) { d.bmp.close(); send({ t: 'out', bmp: null }); return; } busy = true; onFrame(d.bmp, d.ts); }
    else if (d.t === 'go') pendingGo = { gone: d.gone };
    else if (d.t === 'reset') { state = 'present'; parts = null; pendingGo = null; resetG(); send({ t: 'state', state }); }
    else if (d.t === 'relearn' && known) { known.fill(0); fillRGB.fill(0); plateF.fill(0); plateOut.fill(0); learnPasses = 0; forceLearnFrames = 75; cover = 0; send({ t: 'calibration', frames: 75 }); }
  });

  (async () => {
    try {
      hands = new Hands({ locateFile: (f) => new URL('vendor/hands/' + f, window.location.href).href });
      hands.setOptions({ maxNumHands: 2, modelComplexity: 1, minDetectionConfidence: 0.5, minTrackingConfidence: 0.5 });
      hands.onResults((r) => { handRes = r; });
      seg = new SelfieSegmentation({ locateFile: (f) => new URL('vendor/selfie_segmentation/' + f, window.location.href).href });
      seg.setOptions({ modelSelection: 1 });
      seg.onResults((r) => { segRes = r; });
      // Initialize sequentially to avoid overlapping WASM startup in the extension page.
      await hands.initialize();
      await seg.initialize();
      send({ t: 'ready' });
    } catch (err) { hands = null; send({ t: 'error', msg: 'engine failed to load: ' + (err && err.message || err), stack: err && err.stack || '' }); }
  })();
})();
