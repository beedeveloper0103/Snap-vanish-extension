// Runs in the page's own world (document_start) so it can swap the camera/mic streams
// that Meet / Teams / Zoom receive. Heavy AI work happens in the hidden engine iframe.
(() => {
  if (window.__snapVanish) return;
  window.__snapVanish = true;

  const TAG = '__sv';
  const MAX_W = 640; // processing/output width. Raise for sharper output, lower for speed.
  let cfg = { enabled: true, sensitivity: 5, duration: 2.5, direction: 'upright', needSound: true };
  let cfgDone; const cfgPromise = new Promise((r) => (cfgDone = r));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const toContent = (m) => window.postMessage({ [TAG]: 1, to: 'content', ...m }, '*');

  /* ---------------- engine iframe ---------------- */
  let engine = null, engineOrigin = '', engineReady = false, engineFailed = false;
  let engState = 'present', coverage = 0, inflight = false, inflightAt = 0, toasted = false;

  function ensureEngine() {
    if (engine || engineFailed) return;
    const url = document.documentElement.dataset.svEngine;
    if (!url) { engineFailed = true; return; }
    engineOrigin = new URL(url).origin;
    engine = document.createElement('iframe');
    engine.src = url;
    engine.setAttribute('aria-hidden', 'true');
    engine.style.cssText = 'position:fixed;left:-9999px;top:0;width:2px;height:2px;border:0;opacity:0;pointer-events:none';
    (document.body || document.documentElement).appendChild(engine);
    setTimeout(() => { if (!engineReady) engineFailed = true; }, 30000);
  }
  const engineSend = (m, tr) => { if (engine && engine.contentWindow) engine.contentWindow.postMessage(m, engineOrigin, tr || []); };

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (!d) return;
    if (e.source === window && d[TAG] && d.to === 'main') {
      if (d.type === 'cfg') {
        const wasOn = cfg.enabled;
        cfg = { ...cfg, ...d.cfg }; cfgDone();
        engineSend({ t: 'cfg', cfg });
        if (wasOn && !cfg.enabled) { engineSend({ t: 'reset' }); setMuted(false); }
      } else if (d.type === 'snapNow') toggle();
      else if (d.type === 'relearn') engineSend({ t: 'relearn' });
      return;
    }
    if (!engine || e.source !== engine.contentWindow) return;
    if (d.t === 'ready') { engineReady = true; engineSend({ t: 'cfg', cfg }); }
    else if (d.t === 'out') { inflight = false; if (pipe && d.bmp) { pipe.ctx.drawImage(d.bmp, 0, 0); d.bmp.close(); } }
    else if (d.t === 'candidate') onCandidate(d.ts);
    else if (d.t === 'state') engState = d.state;
    else if (d.t === 'coverage') coverage = d.v;
    else if (d.t === 'error') { inflight = false; console.warn('[Snap Vanish]', d.msg); }
  });
  toContent({ type: 'hello' });

  /* ---------------- audio: mute + snap-sound detector ---------------- */
  let actx = null, muted = false, clicks = [];
  const chains = new Set(); // {gain, an}
  function ensureAudio() {
    if (actx) return;
    actx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'interactive' });
    const resume = () => actx.state === 'suspended' && actx.resume();
    resume(); addEventListener('click', resume, true); addEventListener('keydown', resume, true);
    const buf = new Float32Array(512); let base = 0.002;
    setInterval(() => {
      const S = cfg.sensitivity, ratio = 8 - 0.6 * S, floor = 0.02 - 0.0015 * S;
      for (const c of chains) {
        c.an.getFloatTimeDomainData(buf);
        let pk = 0; for (let i = 0; i < buf.length; i++) { const a = Math.abs(buf[i]); if (a > pk) pk = a; }
        if (pk > floor && pk > base * ratio) { clicks.push(performance.now()); }
        else base = base * 0.97 + pk * 0.03;
      }
      const t = performance.now(); if (clicks.length) clicks = clicks.filter((c) => t - c < 2000);
    }, 10);
  }
  function setMuted(m) {
    muted = m;
    for (const c of chains) c.gain.gain.setTargetAtTime(m ? 0 : 1, actx.currentTime, 0.015);
  }
  function audioTrackFor(at) {
    ensureAudio();
    const src = actx.createMediaStreamSource(new MediaStream([at]));
    const delay = actx.createDelay(1); delay.delayTime.value = 0.12; // lets us cut the snap click itself
    const gain = actx.createGain(); gain.gain.value = muted ? 0 : 1;
    const dest = actx.createMediaStreamDestination();
    src.connect(delay); delay.connect(gain); gain.connect(dest);
    const hp = actx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 2500;
    const an = actx.createAnalyser(); an.fftSize = 512;
    const z = actx.createGain(); z.gain.value = 0;
    src.connect(hp); hp.connect(an); an.connect(z); z.connect(actx.destination);
    const chain = { gain, an }; chains.add(chain);
    const out = dest.stream.getAudioTracks()[0];
    const stop = out.stop.bind(out);
    out.stop = () => { stop(); at.stop(); chains.delete(chain); try { src.disconnect(); } catch (_) {} };
    return out;
  }

  /* ---------------- snap decision ---------------- */
  let lastToggle = 0;
  function onCandidate(ts) {
    if (!pipe || engState === 'vanishing' || engState === 'returning') return;
    const ok = () => !cfg.needSound || !chains.size || clicks.some((c) => c > ts - 500 && c < ts + 150);
    if (ok()) toggle(); else setTimeout(() => ok() && toggle(), 200);
  }
  function toggle() {
    const now = performance.now();
    if (!pipe || !engineReady || !cfg.enabled || now - lastToggle < 1200) return;
    if (engState === 'present') {
      lastToggle = now; engineSend({ t: 'go', gone: true }); setMuted(true);
    } else if (engState === 'gone') {
      lastToggle = now; engineSend({ t: 'go', gone: false });
      setTimeout(() => setMuted(false), cfg.duration * 1000 * 0.4);
    }
  }

  /* ---------------- video pipeline ---------------- */
  let pipe = null;
  async function makePipe(real) {
    const v = document.createElement('video');
    v.muted = true; v.playsInline = true; v.srcObject = new MediaStream([real]);
    await v.play();
    if (!v.videoWidth) await new Promise((r) => (v.onloadedmetadata = r));
    const sc = Math.min(1, MAX_W / v.videoWidth);
    const W = Math.round((v.videoWidth * sc) / 2) * 2, H = Math.round((v.videoHeight * sc) / 2) * 2;
    const canvas = document.createElement('canvas'); canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext('2d', { alpha: false });
    const track = canvas.captureStream(30).getVideoTracks()[0];
    pipe = { v, W, H, canvas, ctx, track, real, clones: new Set(), devId: (real.getSettings() || {}).deviceId };
    pipe.timer = setInterval(tick, 1000 / 30);
    real.addEventListener('ended', () => { const p = pipe; if (!p) return; [...p.clones].forEach((c) => { c.stop(); c.dispatchEvent(new Event('ended')); }); });
    ensureEngine();
    pipe.statusTimer = setInterval(sendStatus, 1000);
  }
  function tick() {
    const p = pipe; if (!p || p.v.readyState < 2) return;
    if (!(cfg.enabled && engineReady && !engineFailed)) { p.ctx.drawImage(p.v, 0, 0, p.W, p.H); return; }
    const now = performance.now();
    if (inflight && now - inflightAt < 1000) return;
    inflight = true; inflightAt = now;
    createImageBitmap(p.v, { resizeWidth: p.W, resizeHeight: p.H, resizeQuality: 'low' })
      .then((b) => engineSend({ t: 'frame', bmp: b, ts: now }, [b]))
      .catch(() => { inflight = false; });
  }
  function shutdown() {
    const p = pipe; if (!p) return;
    pipe = null; clearInterval(p.timer); clearInterval(p.statusTimer);
    p.real.stop(); p.v.srcObject = null; inflight = false;
    engineSend({ t: 'reset' }); setMuted(false); engState = 'present';
  }
  function sendStatus() {
    toContent({ type: 'status', status: { hasPipeline: !!pipe, engine: engineFailed ? 'error' : engineReady ? 'ready' : 'loading', state: engState, coverage, audio: chains.size > 0 } });
    if (engineReady && !toasted && coverage < 90 && pipe && performance.now() - pipe.created > 6000) {
      toasted = true; toContent({ type: 'toast', text: 'For a clean vanish, step fully out of camera view and click Learn empty room. Wait 5 seconds, then return.' });
    }
  }
  function videoTrackFor(vt) {
    const attach = () => {
      const t = pipe.track.clone();
      const stop = t.stop.bind(t);
      t.stop = () => { stop(); if (!pipe) return; pipe.clones.delete(t); if (!pipe.clones.size) shutdown(); };
      t.applyConstraints = async () => {};
      const gs = t.getSettings.bind(t), devId = pipe.devId, label = vt.label;
      t.getSettings = () => ({ ...gs(), deviceId: devId, facingMode: 'user' });
      Object.defineProperty(t, 'label', { get: () => label });
      pipe.clones.add(t); return t;
    };
    if (pipe) { vt.stop(); return Promise.resolve(attach()); }
    return makePipe(vt).then(() => { pipe.created = performance.now(); return attach(); });
  }

  /* ---------------- getUserMedia hook ---------------- */
  if (!window.MediaDevices || !navigator.mediaDevices) return;
  const origGUM = MediaDevices.prototype.getUserMedia;
  MediaDevices.prototype.getUserMedia = async function (constraints) {
    const stream = await origGUM.call(this, constraints);
    try {
      await Promise.race([cfgPromise, sleep(1500)]);
      if (!cfg.enabled) return stream;
      const out = new MediaStream();
      const vt = stream.getVideoTracks()[0], at = stream.getAudioTracks()[0];
      if (vt) out.addTrack(await videoTrackFor(vt));
      if (at) out.addTrack(audioTrackFor(at));
      return out;
    } catch (err) {
      console.warn('[Snap Vanish] falling back to the normal camera/mic:', err);
      return stream;
    }
  };
})();
