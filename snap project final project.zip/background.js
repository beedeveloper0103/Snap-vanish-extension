// Keyboard shortcut (backup for the finger snap) -> tell the active tab.
chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== 'snap-now') return;
  if (!tab || !tab.id) [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.id) chrome.tabs.sendMessage(tab.id, { type: 'snapNow' }).catch(() => {});
});
